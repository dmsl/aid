AndrOBD GpsProvider
===================

Plugin extension for AndrOBD to provide mobile device's GPS data to AndrOBD

Functionality
-------------

- The AndrOBD GpsProvider provides GPS data of the mobile to the AndrOBD app
- GPS data can be displayed, recorded, charted, stored, loaded together with all other OBD measurements

Configuration
-------------

- No configuration needed
