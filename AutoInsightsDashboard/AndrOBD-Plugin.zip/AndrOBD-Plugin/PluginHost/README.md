# Sample plugin host
Sample module for a plugin host app

This can be used for GUI testing, etc.
