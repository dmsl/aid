# CSV logging plugin
This extension plugin allows to log AndrOBD data items (PIDs) to a CSV file

* Status: WIP

You are welcome to implement/extend functionality
